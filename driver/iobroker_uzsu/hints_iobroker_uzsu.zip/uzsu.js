// license  GPL [http://www.gnu.de]
// author   Uwe Günther
//
// UZSU-Scheduler unter ioBorker für das smartVisu UZSU Widget (device.uzsuicon)
//
// Offset in Höhengrad (Altitude) wird z.Z. noch nicht unterstützt (hierzu müsste die Funktion getTimeAtElevationAngle 
// ausprogramiert werden). Alle anderen Einstellmöglichkeiten des smartVisu UZSU-Widget werden unterstützt (uzsu_type: '0').
// Für die Sonnenstand Berechnung muss in den Sytemeinstellungen von ioBroker der Breiten- und Längengrad eingetragen werden.
//
// Das 'item' für das UZSU-Widget wird unter javascript.<instance>.uzsu.<timername>.timer abgelegt.
// Unter javascript.<instance>.uzsu.<timername>.stateid ist der zu schaltende ioBroker-State als String einzutragen,
// zum Beispiel 'tr-064.0.states.wlan50'. Der Name <timername> wird über die Konstante UZSU definiert.
//
// Beim Start dieses Skripts werden die entsprechenden Objekte angelegt wenn sie noch nicht vorhanden sind und die
// UZSU-Scheduler erstellt. Jeden Tag um 00:01:20 Uhr werden alle UZSU-Scheduler anlegen / neu berechnen.
//
// Alle Timer werden in der folgende Konstante UZSU definiert (hier müssen die Beispiele entsprechend angepasst werden) :
// (nur Konstante UZSU ändern!)
//
const UZSU = [
    // FrizBox WLAN 5GHz
    // {{ device.uzsuicon('', 'javascript.0.uzsu.wlan5.timer', 'Wlan 5GHz', '', '', 'bool', ['An:true','Aus:false']) }}
    {
        description: 'WLAN 5GHz',
        timername: 'wlan5',
        state: 'tr-064.0.states.wlan50' // true / false
    },
    // RGB Dimmer LED Pflanze links
    // {{ device.uzsuicon('', 'javascript.0.uzsu.led_pflanze_l.timer', 'Pflanze links', '', '', 'bool', ['An:true','Aus:false']) }}
    {
        description: 'Dimmer LED Planze links',
        timername: 'led_pflanze_l',
        state: 'alias.0.wohnzimmer.led_pflanze_l.POWER' // true / false
    },
    // RGB Dimmer LED Holzwand
    // {{ device.uzsuicon('', 'javascript.0.uzsu.led_holzwand.timer', 'Holzwand','', '','num') }}
    {
        description: 'Dimmer LED Holzwand',
        timername: 'led_holzwand',
        state: 'alias.0.wohnzimmer.led_holzwand.Dimmer' // 0 - 100%
    },
    // Tannenbaum ein / aus / heller / dunkler
    // {{ device.uzsuicon('', 'javascript.0.uzsu.tannenbaum.timer', 'Beleuchtung', '', '', 'list', 
    //            ['Dim +5:dimup 5','Dim +3:dimup 3','Dim +2:dimup 2','Dim -2:dimdown 2','Dim -3:dimdown 3','Dim -5:dimdown 5']) }}
    {
        description: 'Tannenbaum',
        timername: 'tannenbaum',
        state: 'javascript.0.irtransmitter.irsendcmd_melinera' // dimup 5, dimup 3, dimup 2, dimdown 2, dimdown 3, dimdown 5
    },
    // Jalosie Wohnzimmer auf / zu
    // {{ device.uzsuicon('', 'javascript.0.uzsu.jalosiewohnzimmer.timer', 'Jalosie Wohnzimmer', '', '', 'list', ['Auf:w_auf','Zu:w_zu']) }}
    {
        description: 'alle Jalosien Wohnzimmer auf / zu',
        timername: 'jalosiewohnzimmer',
        state: 'javascript.0.shutter.cmd' // w_auf oder w_zu
    },
];

// #############################
// ### ab hier nichts ändern ###
// #############################

// Loglevel kann über Objektjavascript.<instance>.uzsu.loglevel während der Laufzeit geändert werden
var LOGLEVEL = 2; // 0=aus, 1=minimal; 2=alles
const idUzsu = 'javascript.' + instance + '.uzsu';
const uzsuLoglevel = idUzsu + '.loglevel';
const fC = false; // forceCreation für createState
const UPTIME = 30; // [sec]
const uptimeSec = 'system.adapter.admin.0.uptime';
var uzsuAllTimer;
var cron;
var timerChangeEvents = [];
const suncalc = require('suncalc'); // npm install suncalc
const config = getObject("system.config");
const lat = config.common.latitude;
const long = config.common.longitude;

function initVar() {
    cron = [];
    uzsuAllTimer = [];
    timerChangeEvents = [];

    createState(uzsuLoglevel, undefined, fC, {
        name: 'Loglevel',
        type: 'number',
        def: LOGLEVEL,
        role: 'state'
    });

    UZSU.forEach((e) => {
        const idTimer = idUzsu + '.' + e.timername;
        const timer = idTimer + '.timer';
        const stateId = idTimer + '.stateid';

        timerChangeEvents.push(timer);

        createState(timer, undefined, fC, {
            name: 'timer ' + e.description,
            type: 'string',
            def: '{"active": true}',
            role: 'variable'
        });
        createState(stateId, undefined, true, {
            name: 'state id ' + e.description,
            type: 'string',
            def: e.state,
            role: 'variable'
        });
    });
}

// Offset in Grad zur Sonnenstand Höhe hinzufügen und als neue Timer-Zeit zurückgeben
// z.B. cronSunTime = Sonnenuntergang und mit sunOffsetElevationAngle = +10° Offset
function getTimeAtElevationAngle(cronSunTime, sunOffsetElevationAngle) {
    var sunpos = suncalc.getPosition(cronSunTime, lat, long);
    var elevation = sunpos.altitude * 180 / Math.PI; //  Sonnenstand Höhe
    // var azimut = sunpos.azimuth * 180 / Math.PI + 180; // Sonnenstand Richtung
    elevation += sunOffsetElevationAngle;

    // ?? wie weiter berechnen

    return new Date(cronSunTime);
}

function writeState(stateId, value) {
    if (LOGLEVEL == 2) log('writeState(): ' + 'stateId=' + stateId + ', value=' + value);
    setState(stateId, value);
}

function uzsuScheduleInit(cron, uzsuAllTimer) {
    // alte schedules löschen
    const listSchedules = getSchedules(false);
    listSchedules.forEach((schedule) => {
        if (clearSchedule(schedule)) {
            if (LOGLEVEL == 2) log('uzsuScheduleInit(): ' + 'del schedule:' + JSON.stringify(schedule));
        } else {
            log('uzsuScheduleInit(): ' + 'cant del schedule:' + JSON.stringify(schedule));
        }
    });
    if (LOGLEVEL == 2) getSchedules(false).forEach(schedule => log('uzsuScheduleInit(): error ' + JSON.stringify(schedule)));

    var now = new Date();
    var sunriseTime = getAstroDate("sunrise", now);
    var sunsetTime = getAstroDate("sunset", now);

    if (LOGLEVEL == 2) log('uzsuScheduleInit(): sunriseTime ' + sunriseTime.getHours() + ':' + sunriseTime.getMinutes());
    if (LOGLEVEL == 2) log('uzsuScheduleInit(): sunsetTime ' + sunsetTime.getHours() + ':' + sunsetTime.getMinutes());

    // neue UZSU schedules für einen Tag anlegen
    cron = [];
    uzsuAllTimer.forEach((e) => {
        if (LOGLEVEL == 2) log('uzsuScheduleInit(uzsu): ' + JSON.stringify(e));
        var cronTimeStart = undefined;
        if (e.timeStart != undefined) { // frühstens
            cronTimeStart = new Date(now);
            cronTimeStart.setHours(e.timeStart[0]);
            cronTimeStart.setMinutes(e.timeStart[1]);
        }
        var cronTimeEnd = undefined;
        if (e.timeEnd != undefined) { // spätestens
            cronTimeEnd = new Date(now);
            cronTimeEnd.setHours(e.timeEnd[0]);
            cronTimeEnd.setMinutes(e.timeEnd[1]);
        }

        if (e.isTime) {
            if ((e.timeStart != undefined) && !e.isSunset && !e.isSunrise) { // normaler Timer an festgelegte Zeit
                if (LOGLEVEL == 2) log('uzsuScheduleInit(timeStart): ' + 'dayOfWeek=' + e.dayOfWeek + ', timeStart=' + e.timeStart + ', value=' + e.value);
                var c = schedule({ hour: e.timeStart[0], minute: e.timeStart[1], dayOfWeek: e.dayOfWeek }, function () {
                    writeState(e.item, e.value);
                });
                cron.push(c);
            } else if (e.isSunrise || e.isSunset) { // Sonnenaufgang oder Sonnenuntergang
                var sunOffsetMs = (e.sunOffsetMin != undefined) ? (e.sunOffsetMin * 60 * 1000) : 0;
                var cronSunTime = e.isSunrise ? new Date(sunriseTime.getTime() + sunOffsetMs) :
                    new Date(sunsetTime.getTime() + sunOffsetMs);
                if (e.sunOffsetElevationAngle != undefined)
                    cronSunTime = getTimeAtElevationAngle(cronSunTime, e.sunOffsetElevationAngle);
                if ((cronTimeStart != undefined) && (cronSunTime.getTime() < cronTimeStart.getTime())) // frühstens
                    cronSunTime = new Date(cronTimeStart);
                if ((cronTimeEnd != undefined) && (cronSunTime.getTime() > cronTimeEnd.getTime())) // spätestens
                    cronSunTime = new Date(cronTimeEnd);
                var cronTime = (cronSunTime.getHours() + ':' + cronSunTime.getMinutes()).split(':');
                if (LOGLEVEL == 2) log('uzsuScheduleInit(' + (e.isSunrise ? 'sunrise' : 'sunset') + '): ' + 'dayOfWeek=' + e.dayOfWeek + ', cronTime=' + cronTime + ', value=' + e.value);
                // dieser Sonnenaufgang/Sonnenuntergang Timer gilt nur für den aktuellen Tag!
                var c = schedule({ hour: cronTime[0], minute: cronTime[1], dayOfWeek: e.dayOfWeek }, function () {
                    writeState(e.item, e.value);
                });
                cron.push(c);
            }
        }
    });
}

// Smartvisu UZSU Datenmodell: Austausch über JSON Element
//         {   "active" : bool,
//          "list"      :          Liste von Einträgen mit Schaltzeiten
//          [{"active"  :false,    Ist der einzelne Eintrag darin aktiv ?
//            "rrule"   :'',       Wochen / Tag Programmstring
//            "value"   :0,        Wert, der gesetzt wird
//            "time"    :'00:00'   Uhrzeitstring des Schaltpunktes, '19:00<sunset+15m<22:00' bei SUN-Events, 'series' bei Zeitreihen
//					  Dies wird intern wie folgt zerlegt (nicht Bestandteil des Dict)
//		              "timeMin"  :'',        Untere Schranke SUN
//            		  "timeMax"  :'',        Oberere Schranke SUN
//            		  "timeCron" :'00:00',   Schaltzeitpunkt
//            		  "timeOffset":''        Offset für Schaltzeitpunkt in Minuten oder Grad
//            		  "timeOffsetType":'m'   'm' = Offset in Minuten, '' Offset in Höhengrad (Altitude)
//          ]
//        }
//
// Beispiel:
//
// {
//     "active": true,
//     "list": [
//         {
//             "active": true,
//             "rrule": "FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR,SA,SU",
//             "value": "true",
//             "time": "06:00"
//         },
//         {
//             "active": true,
//             "rrule": "FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR,SA,SU",
//             "value": "false",
//             "time": "22:15"
//         },
//         {
//             "active": true,
//             "rrule": "FREQ=WEEKLY;BYDAY=MO",
//             "value": "false",
//             "time": "06:00<sunrise+14m<20:00"
//         },
//         {
//             "active": true,
//             "rrule": "FREQ=WEEKLY;BYDAY=TU",
//             "value": "true",
//             "time": "20:55<sunset"
//         },
//         {
//             "active": true,
//             "rrule": "FREQ=WEEKLY;BYDAY=TU",
//             "value": "true",
//             "time": "sunset<20:06"
//         }
//     ]
// }

function parseUzsu(uzsuAllTimer, uzsuData, stateId) {
    var uzsuJson = JSON.parse(uzsuData);
    var active = uzsuJson.active;
    if (active == false)
        return;
    var list = uzsuJson.list;
    if (list == undefined) return;
    list.forEach((element) => {
        if (LOGLEVEL == 2) log('parseUzsu(): for ' + stateId + '=' + JSON.stringify(element));
        if (element.active) {
            var e = {
                item: stateId,
                value: isNaN(element.value) ? element.value : parseInt(element.value),
                dayOfWeek: element.rrule.substr(18)
                    .replace('MO', '1').replace('TU', '2').replace('WE', '3')
                    .replace('TH', '4').replace('FR', '5').replace('SA', '6')
                    .replace('SU', '0').split(','),
                timeStart: undefined,
                timeEnd: undefined,
                isSunset: false,
                isSunrise: false,
                sunOffsetMin: undefined,
                sunOffsetElevationAngle: undefined,
                isTime: (element.time == 'undefined') ? false : true,
            };
            if (e.value == 'true') e.value = true;
            if (e.value == 'false') e.value = false;
            for (var i = 0; i < e.dayOfWeek.length; i++) e.dayOfWeek[i] = parseInt(e.dayOfWeek[i]);
            var t = e.isTime ? element.time.split('<') : element.series.split('<');
            t.forEach((param) => {
                // element.time == 
                // element.series == 
                //  "06:00"
                //  "06:00<sunrise+14m"
                //  "06:00<sunrise+14m<20:00"
                //  "sunrise+14m<20:00"
                //  "sunrise"

                if (param.indexOf('sunset') >= 0) {
                    e.isSunset = true;
                    var offset = param.substr(6).trim();
                    var len = offset.length;
                    if (len > 0) {
                        if (offset.indexOf('m') >= 0) {
                            e.sunOffsetMin = parseInt(offset.substr(0, len - 1));
                        } else {
                            e.sunOffsetElevationAngle = parseInt(offset);
                        }
                    }
                } else if (param.indexOf('sunrise') >= 0) {
                    e.isSunrise = true;
                    var offset = param.substr(7).trim();
                    var len = offset.length;
                    if (len > 0) {
                        if (offset.indexOf('m') >= 0) {
                            e.sunOffsetMin = parseInt(offset.substr(0, len - 1));
                        } else {
                            e.sunOffsetElevationAngle = parseInt(offset);
                        }
                    }
                } else if (param.indexOf(':') == 2) { // "06:00"
                    if (e.isSunset || e.isSunrise) {
                        e.timeEnd = param.split(':');
                        e.timeEnd[0] = parseInt(e.timeEnd[0]);
                        e.timeEnd[1] = parseInt(e.timeEnd[1]);
                    } else {
                        e.timeStart = param.split(':');
                        e.timeStart[0] = parseInt(e.timeStart[0]);
                        e.timeStart[1] = parseInt(e.timeStart[1]);
                    }
                }
            });
            uzsuAllTimer.push(e);
        }
    });
}

function initTimer() {
    uzsuAllTimer = [];
    UZSU.forEach((e) => {
        const idTimer = idUzsu + '.' + e.timername;
        const timer = idTimer + '.timer';
        const stateId = idTimer + '.stateid';
        parseUzsu(uzsuAllTimer, getState(timer).val, getState(stateId).val);
    });
    uzsuScheduleInit(cron, uzsuAllTimer);

    var c = schedule({ hour: 0, minute: 0 }, function () {
        setTimeout(function () {
            initTimer(); // immer um 00:01:20 Uhr neue UZSU-Scheduler anlegen / berechnen
        }, (60 * 1000) + 20);
    });
    cron.push(c);
}

// Main:
var enableEvents = false;
initVar();
setTimeout(function () {
    initTimer();
    enableEvents = true;
}, 2000);
//setState('javascript.0.scriptEnabled.release.uzsu', false);

// Events:
on({ id: uzsuLoglevel, change: 'any' }, function (obj) {
    if (!enableEvents) return;
    if (LOGLEVEL > 0) log('uzsuLoglevel() ' + obj.id + ' ist ' + obj.state.val);

    LOGLEVEL = obj.state.val;
});

on({ id: timerChangeEvents, change: 'any' }, function (obj) {
    if (!enableEvents) return;
    if (getState(uptimeSec).val < UPTIME) return;
    if (LOGLEVEL > 0) log('timerChangeEvents() ' + obj.id + ' ist ' + obj.state.val);

    initTimer();
});
